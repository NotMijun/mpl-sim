/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        mpl: {
          dark: '#0f0f13',
          card: '#1a1a23',
          gold: '#ffd700',
          red: '#ff4d4d',
          green: '#4dff4d',
          accent: '#646cff',
        }
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
      }
    },
  },
  plugins: [],
}
