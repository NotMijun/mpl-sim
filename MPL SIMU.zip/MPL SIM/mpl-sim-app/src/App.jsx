import React, { useState, useEffect, useMemo } from 'react';
import { teams } from './data/teams';
import { generateSchedule, calculateStandings } from './utils/schedule';
import Standings from './components/Standings';
import MatchList from './components/MatchList'; // I need to fix the import in my previous thought, it was default export
import Bracket from './components/Bracket';

function App() {
  const [activeTab, setActiveTab] = useState('group');
  const [matches, setMatches] = useState([]);
  const [playoffMatches, setPlayoffMatches] = useState([]);
  const [playoffTeams, setPlayoffTeams] = useState([]);

  // Initialize schedule on mount
  useEffect(() => {
    const initialSchedule = generateSchedule();
    setMatches(initialSchedule);
  }, []);

  const standings = useMemo(() => calculateStandings(matches), [matches]);

  const handleScoreUpdate = (matchId, field, value) => {
    setMatches(prev => prev.map(m => {
      if (m.id === matchId) {
        const updated = { ...m, [field]: value };
        // Auto-detect played status for BO3
        // If either score reaches 2, mark as played
        // If both < 2, not played (unless draw allowed? No, BO3)
        // If both 2 (invalid), handle? Just let user do it.
        updated.played = updated.score1 === 2 || updated.score2 === 2;
        return updated;
      }
      return m;
    }));
  };

  const handleReset = () => {
    if (window.confirm('Are you sure you want to reset all scores?')) {
      const initialSchedule = generateSchedule();
      setMatches(initialSchedule);
      setPlayoffMatches([]);
      setPlayoffTeams([]);
      setActiveTab('group');
    }
  };

  const initPlayoffs = () => {
    // Get Top 6
    const top6 = standings.slice(0, 6);
    setPlayoffTeams(top6);
    
    // Generate empty bracket matches if not exists
    if (playoffMatches.length === 0) {
      const initialPlayoffs = [
        // Play-ins (BO5)
        { id: 'p1', name: 'Match 1', team1: top6[2].id, team2: top6[5].id, score1: 0, score2: 0, bo: 5, nextWin: 'p3', nextLose: null }, // 3 vs 6
        { id: 'p2', name: 'Match 2', team1: top6[3].id, team2: top6[4].id, score1: 0, score2: 0, bo: 5, nextWin: 'p4', nextLose: null }, // 4 vs 5
        
        // Upper Semis (BO5)
        { id: 'p3', name: 'Upper Semis 1', team1: top6[0].id, team2: null, score1: 0, score2: 0, bo: 5, nextWin: 'p5', nextLose: 'p6' }, // 1 vs Winner P1
        { id: 'p4', name: 'Upper Semis 2', team1: top6[1].id, team2: null, score1: 0, score2: 0, bo: 5, nextWin: 'p5', nextLose: 'p6' }, // 2 vs Winner P2
        
        // Upper Final (BO5)
        { id: 'p5', name: 'Upper Final', team1: null, team2: null, score1: 0, score2: 0, bo: 5, nextWin: 'p8', nextLose: 'p7' }, // Winner P3 vs Winner P4

        // Lower Semis (BO5) - Loser P3 vs Loser P4
        { id: 'p6', name: 'Lower Semis', team1: null, team2: null, score1: 0, score2: 0, bo: 5, nextWin: 'p7', nextLose: null }, 
        
        // Lower Final (BO7)
        { id: 'p7', name: 'Lower Final', team1: null, team2: null, score1: 0, score2: 0, bo: 7, nextWin: 'p8', nextLose: null }, // Loser P5 vs Winner P6
        
        // Grand Final (BO7)
        { id: 'p8', name: 'Grand Final', team1: null, team2: null, score1: 0, score2: 0, bo: 7, nextWin: null, nextLose: null }, // Winner P5 vs Winner P7
      ];
      setPlayoffMatches(initialPlayoffs);
    }
  };

  const handlePlayoffScore = (matchId, field, value) => {
    setPlayoffMatches(prev => {
      const newMatches = prev.map(m => m.id === matchId ? { ...m, [field]: value } : m);
      
      // Update progression
      // We need to re-calculate the entire bracket flow based on new scores
      // This is a bit complex to do inside map, so let's do a 2-pass approach or just simple linear update if dependent
      // Actually, React state updates are batched.
      // Let's create a helper function to resolve bracket
      return resolveBracket(newMatches, playoffTeams);
    });
  };

  const resolveBracket = (currentMatches, currentTeams) => {
    // Clone to avoid mutation
    let matches = JSON.parse(JSON.stringify(currentMatches));
    const getMatch = (id) => matches.find(m => m.id === id);
    
    // Helper to get winner/loser
    const getResult = (match) => {
      const bo = match.bo;
      const winThreshold = Math.ceil(bo / 2);
      if (match.score1 >= winThreshold) return { winner: match.team1, loser: match.team2 };
      if (match.score2 >= winThreshold) return { winner: match.team2, loser: match.team1 };
      return { winner: null, loser: null };
    };

    // 1. Resolve Play-ins (P1, P2)
    // Already set initially (Team1/2 are fixed from standings)
    // Update P3, P4 inputs based on P1, P2 results
    ['p1', 'p2'].forEach(pid => {
      const m = getMatch(pid);
      const res = getResult(m);
      if (res.winner) {
        // P1 winner goes to P3 (as team2 usually, team1 is Seed 1)
        // P2 winner goes to P4 (as team2 usually, team1 is Seed 2)
        const targetId = m.nextWin;
        const target = getMatch(targetId);
        if (target) {
           // If P1 (Seed 3 vs 6), winner plays Seed 1 (Team 1 in P3)
           // Wait, usually Seed 1 plays lowest seed? 
           // Standard fixed bracket:
           // Winner (3v6) plays Seed 1.
           // Winner (4v5) plays Seed 2.
           target.team2 = res.winner;
        }
      }
    });

    // 2. Resolve Upper Semis (P3, P4)
    ['p3', 'p4'].forEach(pid => {
      const m = getMatch(pid);
      const res = getResult(m);
      if (res.winner) {
        // Winner to Upper Final (P5)
        const winTarget = getMatch(m.nextWin);
        if (winTarget) {
          if (pid === 'p3') winTarget.team1 = res.winner;
          if (pid === 'p4') winTarget.team2 = res.winner;
        }
        // Loser to Lower Semis (P6)
        const loseTarget = getMatch(m.nextLose);
        if (loseTarget) {
          if (pid === 'p3') loseTarget.team1 = res.loser;
          if (pid === 'p4') loseTarget.team2 = res.loser;
        }
      }
    });

    // 3. Resolve Upper Final (P5)
    const p5 = getMatch('p5');
    const resP5 = getResult(p5);
    if (resP5.winner) {
      // Winner to Grand Final (P8)
      const gf = getMatch('p8');
      gf.team1 = resP5.winner;
      
      // Loser to Lower Final (P7)
      const lf = getMatch('p7');
      lf.team1 = resP5.loser; // Usually awaits winner of Lower Semis
    }

    // 4. Resolve Lower Semis (P6)
    const p6 = getMatch('p6');
    const resP6 = getResult(p6);
    if (resP6.winner) {
      // Winner to Lower Final (P7)
      const lf = getMatch('p7');
      lf.team2 = resP6.winner;
    }

    // 5. Resolve Lower Final (P7)
    const p7 = getMatch('p7');
    const resP7 = getResult(p7);
    if (resP7.winner) {
      // Winner to Grand Final (P8)
      const gf = getMatch('p8');
      gf.team2 = resP7.winner;
    }

    return matches;
  };

  return (
    <div className="min-h-screen bg-mpl-dark text-white font-sans selection:bg-mpl-accent selection:text-white pb-20">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-mpl-dark/90 backdrop-blur-md border-b border-gray-800 shadow-lg">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-br from-mpl-gold to-orange-600 rounded-lg flex items-center justify-center font-bold text-black shadow-lg shadow-orange-900/20">
              MPL
            </div>
            <h1 className="text-xl font-bold tracking-tight glow-text">SIMULATOR</h1>
          </div>
          
          <nav className="flex items-center space-x-1 bg-gray-900/50 p-1 rounded-lg border border-gray-800">
            <button 
              onClick={() => setActiveTab('group')}
              className={`px-4 py-2 rounded-md text-sm font-medium transition-all duration-200 ${activeTab === 'group' ? 'bg-mpl-accent text-white shadow-lg' : 'text-gray-400 hover:text-white hover:bg-white/5'}`}
            >
              Group Stage
            </button>
            <button 
              onClick={() => {
                setActiveTab('playoffs');
                initPlayoffs();
              }}
              className={`px-4 py-2 rounded-md text-sm font-medium transition-all duration-200 ${activeTab === 'playoffs' ? 'bg-mpl-accent text-white shadow-lg' : 'text-gray-400 hover:text-white hover:bg-white/5'}`}
            >
              Playoffs
            </button>
          </nav>

          <button 
            onClick={handleReset}
            className="text-xs font-medium text-red-400 hover:text-red-300 border border-red-900/50 hover:bg-red-900/20 px-3 py-1.5 rounded transition-colors"
          >
            Reset All
          </button>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8">
        {activeTab === 'group' ? (
          <div className="space-y-8 animate-fade-in">
            <section>
              <h2 className="text-2xl font-bold mb-6 flex items-center">
                <span className="w-1 h-8 bg-mpl-gold mr-3 rounded-full"></span>
                Standings
              </h2>
              <Standings standings={standings} />
            </section>
            
            <section>
              <h2 className="text-2xl font-bold mb-6 flex items-center">
                <span className="w-1 h-8 bg-mpl-accent mr-3 rounded-full"></span>
                Matches
              </h2>
              <MatchList matches={matches} teams={teams} onUpdateScore={handleScoreUpdate} />
            </section>
          </div>
        ) : (
          <div className="animate-fade-in">
            <h2 className="text-2xl font-bold mb-6 flex items-center">
              <span className="w-1 h-8 bg-mpl-gold mr-3 rounded-full"></span>
              Playoffs Bracket
            </h2>
            <Bracket matches={playoffMatches} teams={teams} onUpdateScore={handlePlayoffScore} />
          </div>
        )}
      </main>
    </div>
  );
}

export default App;
