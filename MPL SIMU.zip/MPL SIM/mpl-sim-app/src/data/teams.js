export const teams = [
  { id: 'ae', name: 'Alter Ego', logo: '/teams/ae-256.png' },
  { id: 'btr', name: 'Bigetron Alpha', logo: '/teams/btr_vit.png' },
  { id: 'dewa', name: 'Dewa United', logo: '/teams/dewa-united-500.png' },
  { id: 'evos', name: 'EVOS Glory', logo: '/teams/evos-500.png' },
  { id: 'geek', name: 'Geek Fam', logo: '/teams/geek-500.png' },
  { id: 'navi', name: 'Natus Vincere', logo: '/teams/NAVI-2.png' },
  { id: 'onic', name: 'ONIC', logo: '/teams/onic-b-256.png' },
  { id: 'rrq', name: 'RRQ Hoshi', logo: '/teams/rrq-500.png' },
  { id: 'tlid', name: 'Team Liquid ID', logo: '/teams/TLID-Primary500x500.png' },
];
