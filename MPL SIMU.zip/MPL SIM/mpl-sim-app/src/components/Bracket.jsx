import React from 'react';
import TeamLogo from './TeamLogo';

const BracketMatch = ({ match, team1, team2, onUpdateScore }) => {
  const winThreshold = Math.ceil(match.bo / 2);
  const t1Won = match.score1 >= winThreshold;
  const t2Won = match.score2 >= winThreshold;
  const isPlayed = t1Won || t2Won;

  return (
    <div className="bg-mpl-card border border-gray-700 rounded-lg p-3 w-64 shadow-lg relative z-10">
      <div className="text-xs text-gray-500 mb-2 flex justify-between">
        <span>{match.name}</span>
        <span className="text-mpl-gold font-bold">BO{match.bo}</span>
      </div>
      
      {/* Team 1 */}
      <div className={`flex justify-between items-center mb-2 p-1 rounded ${t1Won ? 'bg-green-900/30' : ''}`}>
        <div className="flex items-center space-x-2">
          {team1 ? (
            <>
              <TeamLogo src={team1.logo} alt={team1.name} size="sm" />
              <span className={`text-sm font-bold truncate w-24 ${t1Won ? 'text-green-400' : 'text-white'}`}>{team1.name}</span>
            </>
          ) : (
            <span className="text-gray-600 text-sm italic">TBD</span>
          )}
        </div>
        <input 
          type="number" 
          min="0" 
          max={winThreshold}
          value={match.score1}
          onChange={(e) => onUpdateScore(match.id, 'score1', parseInt(e.target.value) || 0)}
          className="w-10 bg-black border border-gray-600 rounded text-center text-sm"
          disabled={!team1 || !team2}
        />
      </div>

      {/* Team 2 */}
      <div className={`flex justify-between items-center p-1 rounded ${t2Won ? 'bg-green-900/30' : ''}`}>
        <div className="flex items-center space-x-2">
          {team2 ? (
            <>
              <TeamLogo src={team2.logo} alt={team2.name} size="sm" />
              <span className={`text-sm font-bold truncate w-24 ${t2Won ? 'text-green-400' : 'text-white'}`}>{team2.name}</span>
            </>
          ) : (
            <span className="text-gray-600 text-sm italic">TBD</span>
          )}
        </div>
        <input 
          type="number" 
          min="0" 
          max={winThreshold}
          value={match.score2}
          onChange={(e) => onUpdateScore(match.id, 'score2', parseInt(e.target.value) || 0)}
          className="w-10 bg-black border border-gray-600 rounded text-center text-sm"
          disabled={!team1 || !team2}
        />
      </div>
    </div>
  );
};

const Bracket = ({ matches, teams, onUpdateScore }) => {
  const getMatch = (id) => matches.find(m => m.id === id);
  const getTeam = (id) => teams.find(t => t.id === id);

  // Render logic for each match position
  const renderMatch = (id) => {
    const match = getMatch(id);
    if (!match) return null;
    return (
      <BracketMatch 
        match={match} 
        team1={getTeam(match.team1)} 
        team2={getTeam(match.team2)} 
        onUpdateScore={onUpdateScore} 
      />
    );
  };

  if (!matches.length) return <div className="text-center p-10 text-gray-500">Playoffs not started. Go to Group Stage to qualify teams.</div>;

  return (
    <div className="overflow-x-auto p-4">
      <div className="min-w-[1000px] flex space-x-12 relative">
        {/* Column 1: Play-ins */}
        <div className="flex flex-col justify-center space-y-20">
          <div>{renderMatch('p1')}</div>
          <div>{renderMatch('p2')}</div>
        </div>

        {/* Column 2: Upper Semis & Lower Semis */}
        <div className="flex flex-col justify-between py-10">
          <div className="space-y-10">
            <div>{renderMatch('p3')}</div>
            <div>{renderMatch('p4')}</div>
          </div>
          <div className="mt-20">
            <h4 className="text-gray-500 text-xs uppercase font-bold mb-2">Lower Bracket</h4>
            <div>{renderMatch('p6')}</div>
          </div>
        </div>

        {/* Column 3: Upper Final & Lower Final */}
        <div className="flex flex-col justify-center space-y-32">
          <div>{renderMatch('p5')}</div>
          <div>{renderMatch('p7')}</div>
        </div>

        {/* Column 4: Grand Final */}
        <div className="flex flex-col justify-center">
           <div className="scale-110 origin-left border-2 border-mpl-gold rounded-lg shadow-[0_0_20px_rgba(255,215,0,0.3)]">
             {renderMatch('p8')}
           </div>
        </div>
        
        {/* Connector Lines (SVG) - Optional but cool */}
        <svg className="absolute top-0 left-0 w-full h-full pointer-events-none opacity-20" style={{ zIndex: 0 }}>
          {/* Add paths if needed, but simple layout is fine for now */}
        </svg>
      </div>
    </div>
  );
};

export default Bracket;
