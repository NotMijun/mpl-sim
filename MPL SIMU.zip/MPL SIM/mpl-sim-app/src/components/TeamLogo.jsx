import React from 'react';

const TeamLogo = ({ src, alt, size = "md" }) => {
  const sizeClasses = {
    sm: "w-8 h-8",
    md: "w-12 h-12",
    lg: "w-16 h-16",
    xl: "w-24 h-24"
  };

  return (
    <div className={`${sizeClasses[size]} flex items-center justify-center overflow-hidden bg-mpl-card rounded-full p-1 border border-gray-700`}>
      <img src={src} alt={alt} className="w-full h-full object-contain" />
    </div>
  );
};

export default TeamLogo;
