import React from 'react';
import TeamLogo from './TeamLogo';

const Standings = ({ standings }) => {
  return (
    <div className="overflow-x-auto bg-mpl-card rounded-lg shadow-lg border border-gray-800">
      <table className="w-full text-left">
        <thead className="bg-mpl-dark text-gray-400 uppercase text-xs font-bold border-b border-gray-700">
          <tr>
            <th className="p-4 text-center">#</th>
            <th className="p-4">Team</th>
            <th className="p-4 text-center">Match W-L</th>
            <th className="p-4 text-center">Match %</th>
            <th className="p-4 text-center">Game W-L</th>
            <th className="p-4 text-center">Game %</th>
            <th className="p-4 text-center">Diff</th>
            <th className="p-4 text-center">Pts</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-800">
          {standings.map((team, index) => {
            const rank = index + 1;
            const isEliminated = rank > 6;
            const matchRate = team.matchWins + team.matchLosses > 0 
              ? Math.round((team.matchWins / (team.matchWins + team.matchLosses)) * 100) 
              : 0;
            const gameRate = team.gameWins + team.gameLosses > 0
              ? Math.round((team.gameWins / (team.gameWins + team.gameLosses)) * 100)
              : 0;

            return (
              <tr 
                key={team.id} 
                className={`
                  transition-colors hover:bg-white/5
                  ${isEliminated ? 'bg-red-900/20 text-red-200 glow-red border-l-4 border-l-red-500' : ''}
                  ${rank <= 6 ? 'border-l-4 border-l-mpl-green' : ''}
                `}
              >
                <td className="p-4 text-center font-bold text-lg">{rank}</td>
                <td className="p-4 flex items-center space-x-3">
                  <TeamLogo src={team.logo} alt={team.name} size="sm" />
                  <span className="font-semibold">{team.name}</span>
                </td>
                <td className="p-4 text-center font-mono">
                  {team.matchWins} - {team.matchLosses}
                </td>
                <td className="p-4 text-center font-mono text-gray-400">
                  {matchRate}%
                </td>
                <td className="p-4 text-center font-mono">
                  {team.gameWins} - {team.gameLosses}
                </td>
                <td className="p-4 text-center font-mono text-gray-400">
                  {gameRate}%
                </td>
                <td className={`p-4 text-center font-bold ${team.gameDiff > 0 ? 'text-green-400' : team.gameDiff < 0 ? 'text-red-400' : 'text-gray-400'}`}>
                  {team.gameDiff > 0 ? '+' : ''}{team.gameDiff}
                </td>
                <td className="p-4 text-center font-bold text-xl text-mpl-gold">
                  {team.points}
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
      <div className="p-4 text-xs text-gray-500 flex justify-end space-x-4">
        <div className="flex items-center"><div className="w-3 h-3 bg-mpl-green mr-2"></div> Playoffs Qualifier</div>
        <div className="flex items-center"><div className="w-3 h-3 bg-red-900/50 border border-red-500 mr-2"></div> Eliminated</div>
      </div>
    </div>
  );
};

export default Standings;
