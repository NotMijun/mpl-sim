import React from 'react';

const MatchList = ({ matches, teams, onUpdateScore }) => {
  // Group matches by week
  const matchesByWeek = matches.reduce((acc, match) => {
    if (!acc[match.week]) acc[match.week] = [];
    acc[match.week].push(match);
    return acc;
  }, {});

  const getTeam = (id) => teams.find(t => t.id === id);

  return (
    <div className="space-y-8">
      {Object.entries(matchesByWeek).map(([week, weekMatches]) => (
        <div key={week} className="bg-mpl-card rounded-lg p-6 border border-gray-800">
          <h3 className="text-xl font-bold text-mpl-gold mb-4 border-b border-gray-700 pb-2">Week {week}</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {weekMatches.map(match => {
              const team1 = getTeam(match.team1);
              const team2 = getTeam(match.team2);
              
              // Determine winner for styling
              const t1Won = match.played && match.score1 > match.score2;
              const t2Won = match.played && match.score2 > match.score1;

              return (
                <div key={match.id} className="bg-mpl-dark rounded-md p-3 flex flex-col space-y-2 border border-gray-700 relative overflow-hidden">
                  {/* Team 1 Row */}
                  <div className={`
                    flex justify-between items-center p-2 rounded transition-all duration-300
                    ${t1Won ? 'bg-green-900/50 border-l-4 border-green-500' : match.played ? 'bg-red-900/20 opacity-70' : 'bg-gray-800/50'}
                  `}>
                    <div className="flex items-center space-x-2">
                      <img src={team1.logo} alt={team1.name} className="w-8 h-8 object-contain" />
                      <span className={`font-bold ${t1Won ? 'text-green-400' : 'text-gray-300'}`}>{team1.name}</span>
                    </div>
                    <select 
                      value={match.score1} 
                      onChange={(e) => onUpdateScore(match.id, 'score1', parseInt(e.target.value))}
                      className="bg-black text-white border border-gray-600 rounded px-2 py-1 w-12 text-center focus:outline-none focus:border-mpl-accent"
                    >
                      {[0, 1, 2].map(s => <option key={s} value={s}>{s}</option>)}
                    </select>
                  </div>

                  {/* VS Separator (Visual only) */}
                  <div className="text-center text-xs text-gray-600 font-mono -my-1">VS</div>

                  {/* Team 2 Row */}
                  <div className={`
                    flex justify-between items-center p-2 rounded transition-all duration-300
                    ${t2Won ? 'bg-green-900/50 border-l-4 border-green-500' : match.played ? 'bg-red-900/20 opacity-70' : 'bg-gray-800/50'}
                  `}>
                    <div className="flex items-center space-x-2">
                      <img src={team2.logo} alt={team2.name} className="w-8 h-8 object-contain" />
                      <span className={`font-bold ${t2Won ? 'text-green-400' : 'text-gray-300'}`}>{team2.name}</span>
                    </div>
                    <select 
                      value={match.score2} 
                      onChange={(e) => onUpdateScore(match.id, 'score2', parseInt(e.target.value))}
                      className="bg-black text-white border border-gray-600 rounded px-2 py-1 w-12 text-center focus:outline-none focus:border-mpl-accent"
                    >
                      {[0, 1, 2].map(s => <option key={s} value={s}>{s}</option>)}
                    </select>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      ))}
    </div>
  );
};

export default MatchList;
