import { teams } from '../data/teams';

export const generateSchedule = () => {
  const teamIds = teams.map(t => t.id);
  // Add dummy if odd
  if (teamIds.length % 2 !== 0) {
    teamIds.push('BYE');
  }

  const n = teamIds.length;
  const rounds = n - 1;
  const matchesPerRound = n / 2;
  
  let matches = [];
  let matchId = 1;

  // Single Round Robin
  const singleRoundMatches = [];
  
  // Clone teamIds for rotation
  let currentTeams = [...teamIds];

  for (let r = 0; r < rounds; r++) {
    const roundMatches = [];
    for (let i = 0; i < matchesPerRound; i++) {
      const home = currentTeams[i];
      const away = currentTeams[n - 1 - i];
      
      if (home !== 'BYE' && away !== 'BYE') {
        roundMatches.push({
          home,
          away
        });
      }
    }
    singleRoundMatches.push(roundMatches);

    // Rotate: Keep index 0 fixed, rotate the rest
    // [0, 1, 2, 3] -> [0, 3, 1, 2]
    const fixed = currentTeams[0];
    const rotated = currentTeams.slice(1);
    const last = rotated.pop();
    rotated.unshift(last);
    currentTeams = [fixed, ...rotated];
  }

  // Generate full double round robin
  // First half
  singleRoundMatches.forEach((roundMatches, rIndex) => {
    roundMatches.forEach(m => {
      matches.push({
        id: matchId++,
        week: Math.floor(rIndex / 2) + 1, // Rough week estimation
        team1: m.home,
        team2: m.away,
        score1: 0,
        score2: 0,
        played: false,
        winner: null,
        bo: 3
      });
    });
  });

  // Second half (swap home/away)
  singleRoundMatches.forEach((roundMatches, rIndex) => {
    roundMatches.forEach(m => {
      matches.push({
        id: matchId++,
        week: Math.floor((rIndex + rounds) / 2) + 1,
        team1: m.away,
        team2: m.home,
        score1: 0,
        score2: 0,
        played: false,
        winner: null,
        bo: 3
      });
    });
  });

  return matches;
};

export const calculateStandings = (matches) => {
  const stats = {};
  
  // Initialize stats
  teams.forEach(t => {
    stats[t.id] = {
      id: t.id,
      name: t.name,
      logo: t.logo,
      matchWins: 0,
      matchLosses: 0,
      gameWins: 0,
      gameLosses: 0,
      points: 0, // Match wins
      gameDiff: 0
    };
  });

  matches.forEach(m => {
    if (m.played) {
      // Update Game stats
      stats[m.team1].gameWins += m.score1;
      stats[m.team1].gameLosses += m.score2;
      stats[m.team2].gameWins += m.score2;
      stats[m.team2].gameLosses += m.score1;

      // Update Match stats
      if (m.score1 > m.score2) {
        stats[m.team1].matchWins += 1;
        stats[m.team1].points += 1;
        stats[m.team2].matchLosses += 1;
      } else {
        stats[m.team2].matchWins += 1;
        stats[m.team2].points += 1;
        stats[m.team1].matchLosses += 1;
      }
    }
  });

  // Calculate Game Diff
  Object.values(stats).forEach(s => {
    s.gameDiff = s.gameWins - s.gameLosses;
  });

  // Sort
  return Object.values(stats).sort((a, b) => {
    if (b.points !== a.points) return b.points - a.points;
    if (b.gameDiff !== a.gameDiff) return b.gameDiff - a.gameDiff;
    return 0; // Head to head not implemented for simplicity
  });
};
